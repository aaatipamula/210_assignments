''' 
Program: EECS 210 Assignment 6
Inputs: No inputs to file required.
Outputs: No inputs required, outputs all the values of the required test cases
Collaborators/Sources: N/A
Name: Aniketh Aatipamula
Creation-Date: 11/28/2023
Description: Run the main program
'''

from ext import q1, q2, q3, q4

def main() -> None:
    q1()
    q2()
    q3()
    q4()

if __name__ == "__main__":
    main()
